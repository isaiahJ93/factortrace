from factortrace.models.uncertainty_model import UncertaintyAssessment, DistributionEnum
def test_uncertainty_distribution():
    u = UncertaintyAssessment(
        uncertainty_percentage=10.0,
        confidence_level=95.0,
        distribution=DistributionEnum.LOGNORMAL,
        method="Monte Carlo"
    )
    assert u.uncertainty_percentage == 10.0