from factortrace.models.emissions_voucher import MaterialityAssessment
from api.schemas import VoucherInput
from generator.voucher_generator import generate_voucher
from factortrace.models.emissions import UncertaintyAssessment
from factortrace.schema_loader import schema  
from factortrace.models.materiality import MaterialityAssessment
from factortrace.models.emissions_voucher import MaterialityAssessment, MaterialityType

def test_materiality_parsing():
    example = MaterialityAssessment(
        assessment_date="2025-06-11",
        materiality_type=MaterialityType.double_materiality,
        impact_magnitude=3.5,
        impact_likelihood=3.0,
        impact_scope=["upstream"],
        impact_score=4.0,
        financial_time_horizon="medium",
        financial_likelihood=2.5,
        financial_score=4.2,
        materiality_threshold=0.1,
        is_material=True,
        justification="Double materiality confirmed"
    )
    assert example.is_material is True
    print(example.model_dump_json(indent=2))  # Use .json() if you're on Pydantic v1
    assert example.impact_materiality.magnitude == "HIGH"

    from app.utils.xml_utils import schema

def test_schema_loads():
    from factortrace.schema_loader import schema
    print("✅ XSD schema loaded successfully")

from factortrace.models.emissions_voucher import EmissionsRecord

from factortrace.models.emissions_voucher import EmissionVoucher

from factortrace.models.emissions import UncertaintyAssessment  # or emissions_voucher

def test_uncertainty_distribution():
    u = UncertaintyAssessment(
        uncertainty_percentage=10.0,
        lower_bound=90.0,
        upper_bound=110.0,
        confidence_level=95.0,
        distribution="LOGNORMAL",
        method="Monte Carlo"
    )
    assert u.distribution == "LOGNORMAL"
    assert ua.confidence_level == 90
    assert ua.uncertainty_percentage == 10.0

def test_valid_voucher():
    voucher = EmissionVoucher(
        supplier_lei="5493001KTIIGC8YR12A2",  # valid LEI pattern
        supplier_name="Acme Metals",
        supplier_country="DE",
        supplier_sector="Steel",
        reporting_entity_lei="5493001KTIIGC8YR12A2",
        reporting_period_start="2024-01-01",
        reporting_period_end="2024-12-31",
        consolidation_method="operational_control",
        emissions_records=[{"type": "scope3", "amount": 100}],  # minimal valid
        total_emissions_tco2e=100.0
    )
    assert voucher.total_emissions_tco2e == 100.0

def test_invalid_scope():
    try:
        EmissionVoucher(Scope="INVALID")
    except ValueError:
        assert True

def test_voucher_xml_is_valid():
    sample = {
        "supplier_id": "SUP-001",
        "supplier_name": "Acme Metals",
        "legal_entity_identifier": "5493001KTIIIGC8YR1212",
        "product_category": "Materials",
        "cost": 1200.0,
        "material_type": "Steel",
        "origin_country": "DE",
        "emission_factor": 2.5,
        "emission_factor_id": "EF-001",  
        "fallback_factor_used": False,
}

    voucher = generate_voucher(VoucherInput(**sample))  # ✅ wrap dict in model
    assert "co2e" in voucher

emissions_records=[
    {
        "scope": "scope3",
        "value_chain_stage": "upstream",
        "activity_description": "Electricity usage",
        "activity_value": 100,
        "activity_unit": "MWh",
        "emission_factor": 0.25,
        "ghg_breakdown": {"CO2": 25},
        "total_emissions_tco2e": 25,
        "data_quality": "high",
        "calculation_method": "measured",
        "emission_date_start": "2024-01-01",
        "emission_date_end": "2024-12-31"
    }
]
def test_materiality_parsing():
    example = MaterialityAssessment(
        impact_magnitude=3.5,
        impact_likelihood="LIKELY",
        time_horizon="LONG_TERM",
        affected_stakeholders=["investors", "NGOs"],
        financial_impact=1_500_000.0,
        risk_type="PHYSICAL",
        reporting_period="2025"
    )
    assert example.impact_magnitude == 3.5