from factortrace.models.materiality import MaterialityAssessment

def test_materiality_parsing():
    example = MaterialityAssessment(
        impact_magnitude=3.5,
        impact_likelihood="LIKELY",
        time_horizon="LONG_TERM",
        affected_stakeholders=["investors", "NGOs"],
        financial_impact=1500000.0,
        risk_type="PHYSICAL",
        reporting_period="MEDIUM_TERM"
    )
    assert example.impact_magnitude == 3.5
def test_basic_math():
    assert 2 + 2 == 4
    