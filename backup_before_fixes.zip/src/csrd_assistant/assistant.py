from __future__ import annotations
def run(prompt: str) -> str:
    """
    Thin wrapper that hands `prompt` to your LLM client and returns the answer.
    Keeps it framework-agnostic so tests & CLI stay lightweight.
    """
    ...
