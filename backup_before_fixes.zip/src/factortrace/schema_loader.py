from __future__ import annotations
schema = {
    "type": "object",
    "properties": {
        "example_field": {"type": "string"}
    },
    "required": ["example_field"]
}
