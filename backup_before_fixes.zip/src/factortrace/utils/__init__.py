from __future__ import annotations
"""utils package"""
from .xml_validation import validate_vsme_xml

def validate_vsme_xml(xml_str: str):        # simple always-pass stub
    return True, []