from __future__ import annotations
def add_to_xml_method(cls):
    """
    Stub decorator that can be extended to add XML export capabilities.
    """
    return cls

