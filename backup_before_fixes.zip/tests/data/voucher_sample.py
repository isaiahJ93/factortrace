SAMPLE_DATA = {
    "supplier_lei": "1234567890ABCDEF1234",
    "supplier_name": "Acme Metals",
    "supplier_country": "DE",
    "supplier_sector": "Steel",
    "reporting_entity_lei": "1234567890ABCDEF1234",
    "reporting_period_start": "2024-01-01",
    "reporting_period_end": "2024-12-31",
    "consolidation_method": "operational_control",
    "emissions_records": [],
    "total_emissions_tco2e": 100.0,
}