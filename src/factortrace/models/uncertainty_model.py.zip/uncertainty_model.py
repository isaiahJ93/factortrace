from pydantic import BaseModel, Field
from enum import Enum
from typing import Optional

class DistributionEnum(str, Enum):
    LOGNORMAL = "LOGNORMAL"
    NORMAL    = "NORMAL"
    UNIFORM   = "UNIFORM"
    TRIANGULAR = "TRIANGULAR"

class UncertaintyAssessment(BaseModel):
    uncertainty_percentage: float = Field(alias="UncertaintyPercentage")
    lower_bound: Optional[float] = Field(default=None, alias="LowerBound")
    upper_bound: Optional[float] = Field(default=None, alias="UpperBound")
    confidence_level: float = Field(default=95, alias="ConfidenceLevel")
    distribution: Optional[DistributionEnum] = Field(default=None, alias="Distribution")
    method: Optional[str] = Field(default=None, alias="Method")