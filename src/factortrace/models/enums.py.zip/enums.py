from enum import Enum
from pydantic import BaseModel
from typing import Optional

class ScopeLevelEnum(str, Enum):
    """GHG Protocol emission scopes per ESRS E1-6 §44"""
    SCOPE_1 = "scope_1"
    SCOPE_2_LOCATION = "scope_2_location"
    SCOPE_2_MARKET = "scope_2_market"
    SCOPE_3 = "scope_3"

class AuditActionEnum(str, Enum):
    CREATED = "created"
    UPDATED = "updated"
    DELETED = "deleted"

class ScopeEnum(str, Enum):
    SCOPE_1 = "SCOPE_1"
    SCOPE_2 = "SCOPE_2"
    SCOPE_3 = "SCOPE_3"

class Scope3CategoryEnum(str, Enum):
    CATEGORY_1 = "CATEGORY_1"
    CATEGORY_2 = "CATEGORY_2"
    # Add full set as per your spec

class ValueChainStageEnum(str, Enum):
    UPSTREAM = "UPSTREAM"
    DIRECT_OPERATIONS = "DIRECT_OPERATIONS"
    DOWNSTREAM = "DOWNSTREAM"

class GWPVersionEnum(str, Enum):
    AR4 = "AR4"
    AR5 = "AR5"
    AR6 = "AR6"

class ConsolidationMethodEnum(str, Enum):
    OPERATIONAL_CONTROL = "OPERATIONAL_CONTROL"
    FINANCIAL_CONTROL = "FINANCIAL_CONTROL"
    EQUITY_SHARE = "EQUITY_SHARE"

class DistributionEnum(str, Enum):
    NORMAL = "NORMAL"
    LOGNORMAL = "LOGNORMAL"
    UNIFORM = "UNIFORM"
    TRIANGULAR = "TRIANGULAR"

class TargetTypeEnum(str, Enum):
    ABSOLUTE = "ABSOLUTE"
    INTENSITY = "INTENSITY"

 

class AuditActionEnum(str, Enum):
    CREATED = "CREATED"
    MODIFIED = "MODIFIED"
    VALIDATED = "VALIDATED"
    EXPORT_XBRL = "EXPORT_XBRL"
    EXPORT_PDF = "EXPORT_PDF"
    SYSTEM_UPDATE = "SYSTEM_UPDATE"


class TierLevelEnum(str, Enum):
    TIER_1 = "tier_1"
    TIER_2 = "tier_2"
    TIER_3 = "tier_3"
    TIER_4 = "tier_4"


class DataQuality(BaseModel):
    tier: TierLevelEnum
    score: int
    temporal_representativeness: int
    geographical_representativeness: int
    technological_representativeness: int
    completeness: int
    uncertainty_percent: int
    confidence_level: Optional[int] = None
    distribution: Optional[str] = None

class EmissionFactor(BaseModel):
    factor_id: str
    value: float
    unit: str
    source: str
    source_year: int
    tier: str
    country_code: Optional[str] = None
    is_cbam_default: Optional[bool] = False