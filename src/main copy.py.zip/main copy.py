from fastapi import FastAPI
from factortrace.routes.admin import admin_router
from generator.xhtml_generator import generate_ixbrl
from cli.generate_report import generate_compliance_report
from dotenv import load_dotenv
load_dotenv()
if __name__ == "__main__":
    generate_compliance_report()

sample_data = {
    "lei": "5493001KJTIIGC8Y1R12",
    "total_emissions": 74295.3
}

generate_ixbrl(sample_data, "output/report.xhtml")
print("✅ XHTML iXBRL file generated at output/report.xhtml")

app = FastAPI()
app.include_router(admin_router, prefix="/admin")

@app.on_event("startup")
async def log_routes():
    for route in app.routes:
        print(f"✅ Route registered: {route.path} [{route.methods}]")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("src.main:app", host="127.0.0.1", port=8000, reload=True)

