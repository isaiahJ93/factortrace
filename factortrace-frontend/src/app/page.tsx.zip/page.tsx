'use client'

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadialBarChart, RadialBar, AreaChart, Area } from 'recharts';
import { Activity, TrendingUp, AlertCircle, CheckCircle, Download, Plus, FileText, BarChart3, Zap, Gauge } from 'lucide-react';

const FactorTraceDashboard = () => {
  const router = useRouter();
  const [selectedScope, setSelectedScope] = useState('all');
  const [animatedValues, setAnimatedValues] = useState({
    totalEmissions: 0,
    dataQuality: 0,
    compliance: 0
  });

  // Animate numbers on mount
  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatedValues(prev => ({
        totalEmissions: Math.min(prev.totalEmissions + 12.5, 1247.3),
        dataQuality: Math.min(prev.dataQuality + 1, 87),
        compliance: Math.min(prev.compliance + 1, 92)
      }));
    }, 20);

    setTimeout(() => clearInterval(interval), 2000);
    return () => clearInterval(interval);
  }, []);

  // Sample data
  const emissionsByScope = [
    { name: 'Scope 1', value: 234.5, percentage: 18.8, color: '#6366F1' },
    { name: 'Scope 2', value: 156.2, percentage: 12.5, color: '#8B5CF6' },
    { name: 'Scope 3', value: 856.6, percentage: 68.7, color: '#EC4899' }
  ];

  const monthlyTrend = [
    { month: 'Jan', scope1: 220, scope2: 150, scope3: 810, quality: 82 },
    { month: 'Feb', scope1: 225, scope2: 148, scope3: 825, quality: 84 },
    { month: 'Mar', scope1: 230, scope2: 152, scope3: 840, quality: 85 },
    { month: 'Apr', scope1: 234.5, scope2: 156.2, scope3: 856.6, quality: 87 }
  ];

  const dataQualityMetrics = [
    { category: 'Primary Data', score: 92, color: '#10B981' },
    { category: 'Estimates', score: 78, color: '#F59E0B' },
    { category: 'Proxies', score: 65, color: '#EF4444' }
  ];

  const complianceStatus = [
    { standard: 'CSRD', status: 'Compliant', progress: 100 },
    { standard: 'ESRS E1', status: 'In Progress', progress: 87 },
    { standard: 'CBAM', status: 'In Progress', progress: 92 },
    { standard: 'SBTi', status: 'Pending', progress: 78 }
  ];

  const materialCategories = [
    { name: 'Transportation', emissions: 342.1, quality: 89, trend: '+2.3%' },
    { name: 'Purchased Goods', emissions: 289.4, quality: 85, trend: '-1.2%' },
    { name: 'Capital Goods', emissions: 156.7, quality: 92, trend: '+0.8%' },
    { name: 'Fuel & Energy', emissions: 134.2, quality: 94, trend: '-3.1%' },
    { name: 'Waste', emissions: 89.3, quality: 78, trend: '+1.5%' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      {/* Header */}
      <header className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Zap className="w-8 h-8 text-emerald-500" />
              FactorTrace Dashboard
            </h1>
            <p className="text-gray-600 mt-1">Real-time emissions monitoring & compliance tracking</p>
          </div>
          <div className="flex gap-3">
            <button className="px-4 py-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Generate Report
            </button>
            <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors flex items-center gap-2">
              <Plus className="w-4 h-4" />
              New Voucher
            </button>
          </div>
        </div>
      </header>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Total Emissions</span>
            <Activity className="w-5 h-5 text-emerald-500" />
          </div>
          <div className="text-3xl font-bold text-gray-900">
            {animatedValues.totalEmissions.toFixed(1)} tCO₂e
          </div>
          <div className="mt-2 flex items-center text-sm">
            <TrendingUp className="w-4 h-4 text-emerald-500 mr-1" />
            <span className="text-emerald-600">2.3% vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Data Quality Score</span>
            <BarChart3 className="w-5 h-5 text-blue-500" />
          </div>
          <div className="text-3xl font-bold text-gray-900">{animatedValues.dataQuality}%</div>
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-500"
                style={{ width: `${animatedValues.dataQuality}%` }}
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Compliance Rate</span>
            <CheckCircle className="w-5 h-5 text-emerald-500" />
          </div>
          <div className="text-3xl font-bold text-gray-900">{animatedValues.compliance}%</div>
          <div className="mt-2 flex items-center gap-2">
            {['CSRD', 'ESRS', 'CBAM'].map(std => (
              <span key={std} className="text-xs px-2 py-1 bg-emerald-100 text-emerald-700 rounded-full">
                {std}
              </span>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-600">Active Vouchers</span>
            <FileText className="w-5 h-5 text-purple-500" />
          </div>
          <div className="text-3xl font-bold text-gray-900">14</div>
          <div className="mt-2 text-sm text-gray-600">
            3 pending review
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Emissions by Scope */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Emissions by Scope</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={emissionsByScope}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name}: ${percentage}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  animationBegin={0}
                  animationDuration={800}
                >
                  {emissionsByScope.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2">
            {emissionsByScope.map(scope => (
              <div key={scope.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: scope.color }} />
                  <span className="text-sm text-gray-600">{scope.name}</span>
                </div>
                <span className="text-sm font-medium text-gray-900">{scope.value} tCO₂e</span>
              </div>
            ))}
          </div>
        </div>

        {/* Monthly Trend */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Emissions Trend</h3>
            <div className="flex gap-2">
              {['all', '1', '2', '3'].map(scope => (
                <button
                  key={scope}
                  onClick={() => setSelectedScope(scope)}
                  className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                    selectedScope === scope 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {scope === 'all' ? 'All Scopes' : `Scope ${scope}`}
                </button>
              ))}
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="scope1" stackId="1" stroke="#6366F1" fill="#6366F1" fillOpacity={0.6} />
                <Area type="monotone" dataKey="scope2" stackId="1" stroke="#8B5CF6" fill="#8B5CF6" fillOpacity={0.6} />
                <Area type="monotone" dataKey="scope3" stackId="1" stroke="#EC4899" fill="#EC4899" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Data Quality Distribution */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Data Quality Distribution</h3>
          <div className="space-y-4">
            {dataQualityMetrics.map(metric => (
              <div key={metric.category}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">{metric.category}</span>
                  <span className="text-sm font-semibold" style={{ color: metric.color }}>
                    {metric.score}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="h-3 rounded-full transition-all duration-500"
                    style={{ 
                      width: `${metric.score}%`,
                      backgroundColor: metric.color
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-blue-900">Improve Data Quality</p>
                <p className="text-xs text-blue-700 mt-1">
                  Replace 15% of estimates with primary data to reach 90% quality score
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Material Categories */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 lg:col-span-2">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Emission Categories</h3>
          <div className="space-y-3">
            {materialCategories.map(category => (
              <div key={category.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{category.name}</h4>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-sm text-gray-600">{category.emissions} tCO₂e</span>
                    <div className="flex items-center gap-1">
                      <Gauge className="w-3 h-3 text-gray-500" />
                      <span className="text-sm text-gray-600">Quality: {category.quality}%</span>
                    </div>
                  </div>
                </div>
                <span className={`text-sm font-medium ${
                  category.trend.startsWith('+') ? 'text-red-600' : 'text-emerald-600'
                }`}>
                  {category.trend}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Compliance Status */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Compliance Status</h3>
          <div className="space-y-3">
            {complianceStatus.map(item => (
              <div key={item.standard} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">{item.standard}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    item.status === 'Compliant' 
                      ? 'bg-emerald-100 text-emerald-700'
                      : item.status === 'In Progress'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-gray-100 text-gray-700'
                  }`}>
                    {item.status}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all duration-500 ${
                      item.progress === 100 ? 'bg-emerald-500' : 'bg-blue-500'
                    }`}
                    style={{ width: `${item.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <button className="mt-4 w-full px-4 py-2 bg-emerald-50 text-emerald-700 rounded-lg hover:bg-emerald-100 transition-colors text-sm font-medium">
            View Compliance Report
          </button>
        </div>
      </div>

      {/* Action Bar */}
      <div className="mt-8 bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-1">Ready to generate your XBRL report?</h3>
            <p className="text-emerald-100">All required data points collected with 87% average quality score</p>
          </div>
          <button className="px-6 py-3 bg-white text-emerald-700 rounded-lg hover:bg-emerald-50 transition-colors font-medium flex items-center gap-2">
            <Download className="w-5 h-5" />
            Generate XBRL Voucher
          </button>
        </div>
      </div>
    </div>
  );
};

export default FactorTraceDashboard;