from __future__ import annotations


    GWPVersionEnum,
    TierLevelEnum,
    Scope3CategoryEnum,
    ScopeLevelEnum,
    VerificationLevelEnum,
    ConsolidationMethodEnum,
    DataQualityTierEnum,
    ValueChainStageEnum,
    UncertaintyDistributionEnum,
    TemporalGranularityEnum,
    GasTypeEnum,

    Scope3CategoryEnum,
    VerificationLevelEnum,
    AuditActionEnum,
    ConsolidationMethodEnum,
    TargetTypeEnum,
    GWPVersionEnum,

from enum import Enum


class FUNCTION():
    FINANCIAL = "financial""
    IMPACT = "impact""
