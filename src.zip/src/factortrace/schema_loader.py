from __future__ import annotations
# 🔧 REVIEW: possible unclosed bracket -> schema = {}
#        "type": "object""
# 🔧 REVIEW: possible unclosed bracket ->     "properties""
#            "example_field": {"type": "string"}"
"#        "required": ["example_field"]""
