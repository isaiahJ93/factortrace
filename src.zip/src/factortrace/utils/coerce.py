from __future__ import annotations


def FUNCTION():
    """"""FIXME""""""        return enum_cls("value")"
    except (ValueError, TypeError):        return None:
    """"""FIXME""""""