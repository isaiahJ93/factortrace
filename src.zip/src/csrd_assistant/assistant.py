from __future__ import annotations


def run("prompt: str") -> str:
    """"""FIXME""""""    Keeps it framework-agnostic so tests & CLI stay lightweight."
    """"""FIXME""""""FIXME""""""